package com.baliksehat.app;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.os.*;
import android.graphics.Color;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout root, checklist;
    TextView dayText, progressText;
    SharedPreferences sp;
    String[] taskKeys={"water","breakfast","lunch","walk","dinner","sleep"};
    String[] tasks={"Air putih & tanpa minuman manis","Sarapan sesuai porsi","Makan siang: ½ sayur, ¼ protein, ¼ nasi","Jalan kaki sesuai target hari ini","Makan malam sesuai porsi","Mulai persiapan tidur tepat waktu"};

    int day(){ return sp.getInt("day",1); }
    public void onCreate(Bundle b){
        super.onCreate(b);
        sp=getSharedPreferences("data",0);
        build();
        schedule(this);
        if(Build.VERSION.SDK_INT>=33) requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},77);
    }
    TextView tv(String s,int size){ TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(Color.rgb(22,48,47)); t.setPadding(18,12,18,12); return t; }
    Button btn(String s){ Button b=new Button(this); b.setText(s); return b; }
    void build(){
        ScrollView sv=new ScrollView(this);
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(16,12,16,30); root.setBackgroundColor(Color.rgb(244,247,247));
        TextView h=tv("30 Hari Balik Sehat",26); h.setTextColor(Color.WHITE); h.setBackgroundColor(Color.rgb(15,118,110)); root.addView(h);
        TextView sub=tv("Program 30 hari untuk gula darah, tekanan darah, berat badan & kebugaran.",15); sub.setTextColor(Color.WHITE); sub.setBackgroundColor(Color.rgb(15,118,110)); root.addView(sub);
        dayText=tv("",24); root.addView(dayText);
        progressText=tv("",14); root.addView(progressText);
        checklist=new LinearLayout(this); checklist.setOrientation(LinearLayout.VERTICAL); root.addView(checklist);
        Button next=btn("Selesaikan hari ini & lanjut ke hari berikutnya"); next.setOnClickListener(v->{int d=Math.min(30,day()+1);sp.edit().putInt("day",d).apply();build();}); root.addView(next);
        Button log=btn("Catat berat / tensi / gula"); log.setOnClickListener(v->showLog()); root.addView(log);
        root.addView(tv("Aturan makan: ½ piring sayur, ¼ protein, ¼ nasi/karbohidrat. Utamakan air putih/teh tawar/kopi tanpa gula. Batasi gorengan, kerupuk, makanan sangat asin dan camilan manis.",15));
        root.addView(tv("Olahraga: Hari 1–7 jalan 10–15 menit; hari 8–14 15–20 menit; hari 15–21 20–30 menit + strength ringan 2×/minggu; hari 22–30 jalan 25–35 menit + strength 2–3×/minggu.",15));
        root.addView(tv("Penting: hasil MCU April 2026 menunjukkan gula puasa 217 mg/dL dan 2 jam PP 237 mg/dL. Tetap kontrol dokter, pertimbangkan HbA1c, dan jangan menghentikan obat sendiri.",14));
        sv.addView(root); setContentView(sv); renderChecks();
    }
    void renderChecks(){
        int d=day(); dayText.setText("Hari program: "+d+"/30");
        checklist.removeAllViews(); int done=0;
        for(int i=0;i<tasks.length;i++){
            final String key="d"+d+"_"+taskKeys[i];
            CheckBox c=new CheckBox(this); c.setText(tasks[i]); c.setTextSize(15); c.setPadding(8,8,8,8); c.setChecked(sp.getBoolean(key,false));
            if(c.isChecked()) done++;
            c.setOnCheckedChangeListener((x,checked)->sp.edit().putBoolean(key,checked).apply());
            checklist.addView(c);
        }
        progressText.setText(done+" dari 6 target selesai hari ini");
    }
    void showLog(){
        LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); l.setPadding(30,10,30,10);
        EditText w=new EditText(this);w.setHint("Berat (kg)"); l.addView(w);
        EditText bp=new EditText(this);bp.setHint("Tensi, contoh 135/85"); l.addView(bp);
        EditText g=new EditText(this);g.setHint("Gula darah (mg/dL), opsional"); l.addView(g);
        EditText walk=new EditText(this);walk.setHint("Jalan (menit)"); l.addView(walk);
        new AlertDialog.Builder(this).setTitle("Catatan hari "+day()).setView(l).setPositiveButton("Simpan",(d,which)->{
            sp.edit().putString("w"+day(),w.getText().toString()).putString("bp"+day(),bp.getText().toString()).putString("g"+day(),g.getText().toString()).putString("walk"+day(),walk.getText().toString()).apply();
        }).setNegativeButton("Batal",null).show();
    }
    static void schedule(Context c){
        AlarmManager am=(AlarmManager)c.getSystemService(ALARM_SERVICE);
        String[] times={"07:30","12:30","13:00","18:30","21:30","22:30"};
        String[] msgs={"Waktunya sarapan sesuai porsi.","Waktunya makan siang. Setelah makan, jalan sesuai target.","Jalan kaki 10–35 menit sesuai hari program.","Waktunya makan malam sesuai porsi.","Mulai persiapan tidur.","Target tidur. Usahakan jadwal konsisten."};
        for(int i=0;i<times.length;i++){
            String[] p=times[i].split(":"); Calendar cal=Calendar.getInstance(); cal.set(Calendar.HOUR_OF_DAY,Integer.parseInt(p[0])); cal.set(Calendar.MINUTE,Integer.parseInt(p[1])); cal.set(Calendar.SECOND,0); if(cal.getTimeInMillis()<=System.currentTimeMillis())cal.add(Calendar.DAY_OF_YEAR,1);
            Intent in=new Intent(c,ReminderReceiver.class); in.putExtra("msg",msgs[i]); PendingIntent pi=PendingIntent.getBroadcast(c,100+i,in,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
            if(Build.VERSION.SDK_INT>=23) am.setInexactRepeating(AlarmManager.RTC_WAKEUP,cal.getTimeInMillis(),AlarmManager.INTERVAL_DAY,pi);
        }
    }
}