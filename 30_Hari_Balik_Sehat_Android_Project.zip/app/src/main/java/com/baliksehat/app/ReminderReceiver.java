package com.baliksehat.app;
import android.app.*; import android.content.*; import android.os.Build;
public class ReminderReceiver extends BroadcastReceiver {
 public void onReceive(Context c,Intent i){
  String ch="health_reminders";
  NotificationManager nm=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
  if(Build.VERSION.SDK_INT>=26) nm.createNotificationChannel(new NotificationChannel(ch,"Pengingat Balik Sehat",NotificationManager.IMPORTANCE_DEFAULT));
  Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(c,ch):new Notification.Builder(c);
  b.setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle("30 Hari Balik Sehat").setContentText(i.getStringExtra("msg")).setAutoCancel(true);
  nm.notify((int)(System.currentTimeMillis()/1000),b.build());
 }
}