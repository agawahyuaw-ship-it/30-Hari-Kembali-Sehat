CARA MEMBUAT APK TANPA KOMPUTER

Cara yang saya siapkan adalah GitHub Actions (build di cloud).

1. Buat/login akun GitHub lewat Chrome di HP.
2. Buat repository baru, misalnya: 30-hari-balik-sehat.
3. Upload SEMUA file/folder dari ZIP ini ke repository.
4. Pastikan file .github/workflows/build-apk.yml ikut ter-upload.
5. Buka tab Actions -> workflow "Build APK" -> Run workflow.
6. Tunggu sampai status hijau (build selesai).
7. Buka hasil workflow -> bagian Artifacts -> download "30-hari-balik-sehat-apk".
8. Ekstrak ZIP artifact. Di dalamnya ada app-debug.apk.
9. Buka APK di Samsung -> izinkan instalasi dari sumber ini bila diminta -> Install.

Catatan:
- Ini versi 1 dan masih memakai desain sederhana.
- Notifikasi dijadwalkan oleh AlarmManager.
- Data catatan disimpan lokal di HP.
- Aplikasi adalah pendamping gaya hidup, bukan pengganti dokter.
- Jangan menghentikan obat diabetes/hipertensi tanpa dokter.
